$(document).ready(function() {
	$(".callback__input--phone").mask("+38(999) 999-99-99");
});

